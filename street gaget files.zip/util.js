'use strict';

const CITY_CENTRE = { lat: 11.6643, lng: 78.146 }; // Salem Junction area

function haversineKm(a, b) {
  const R = 6371;
  const rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.sqrt(x)) * 10) / 10;
}

function discountPct(price, mrp) {
  if (!mrp || price >= mrp) return 0;
  return Math.round(((mrp - price) / mrp) * 100);
}

// Standard reducing-balance EMI. rate = % per year, months = tenure.
function emiCalc(price, down, rate, months) {
  const principal = Math.max(0, price - down);
  if (!principal || !months) return { principal: 0, emi: 0, totalInterest: 0, totalPayable: price };
  const r = rate / 12 / 100;
  const emi = r === 0 ? principal / months : (principal * r * (1 + r) ** months) / ((1 + r) ** months - 1);
  const totalInterest = emi * months - principal;
  return {
    principal: Math.round(principal),
    emi: Math.round(emi),
    totalInterest: Math.round(totalInterest),
    totalPayable: Math.round(down + emi * months),
  };
}

function digits(s) {
  return String(s || '').replace(/\D/g, '');
}

// Returns a clean 10-digit Indian mobile number or null.
function normalisePhone(s) {
  const d = digits(s).slice(-10);
  return /^[6-9]\d{9}$/.test(d) ? d : null;
}

function num(v, fallback = null) {
  if (v === undefined || v === null || v === '') return fallback;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

module.exports = { CITY_CENTRE, haversineKm, discountPct, emiCalc, normalisePhone, digits, num };
