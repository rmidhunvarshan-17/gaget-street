'use strict';
// Run: node test.js   (uses a temporary DB file, never touches data/db.json)
const os = require('os');
const path = require('path');
process.env.DB_FILE = path.join(os.tmpdir(), `gs-test-${Date.now()}.json`);
process.env.ADMIN_PASSWORD = 'testpass';
const assert = require('assert');
const { server } = require('./server');

let base;
async function api(method, url, body, token) {
  const r = await fetch(base + url, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: r.status, data: await r.json().catch(() => ({})) };
}

(async () => {
  await new Promise((r) => server.listen(0, r));
  base = 'http://localhost:' + server.address().port;
  let passed = 0;
  const t = async (name, fn) => { await fn(); passed++; console.log('  ok -', name); };

  await t('health', async () => assert.equal((await api('GET', '/api/health')).data.ok, true));

  await t('search iPhone sorted by price', async () => {
    const { data } = await api('GET', '/api/search?q=iphone&sort=price');
    assert.equal(data.results.length, 1);
    const ls = data.results[0].listings.filter((l) => l.inStock).map((l) => l.price);
    assert.deepEqual(ls, [...ls].sort((a, b) => a - b));
    assert.ok(data.results[0].stats.lowest <= data.results[0].stats.highest);
  });

  await t('Tamil search alias (மொபைல்)', async () => {
    const { data } = await api('GET', '/api/search?q=' + encodeURIComponent('மொபைல்'));
    assert.ok(data.results.length >= 5);
  });

  await t('search: nearest + area filter', async () => {
    const { data } = await api('GET', '/api/search?q=samsung&sort=nearest&area=fairlands');
    for (const g of data.results) for (const l of g.listings) assert.equal(l.shop.area, 'fairlands');
  });

  await t('budget 30000 never exceeds budget', async () => {
    const { status, data } = await api('GET', '/api/budget?amount=30000&priority=value');
    assert.equal(status, 200);
    assert.ok(data.picks.length > 0);
    for (const p of data.picks) assert.ok(p.best.price <= 30000 && p.best.inStock);
  });

  await t('budget validation', async () => assert.equal((await api('GET', '/api/budget?amount=abc')).status, 400));

  await t('repairs by device, nearest first', async () => {
    const { data } = await api('GET', '/api/repairs?device=laptop');
    assert.ok(data.shops.length >= 2);
    for (const s of data.shops) assert.ok(s.devices.includes('laptop') && s.startingPrice > 0);
    const d = data.shops.map((s) => s.distanceKm);
    assert.deepEqual(d, [...d].sort((a, b) => a - b));
  });

  await t('EMI maths', async () => {
    const { data } = await api('GET', '/api/emi?price=60000&down=10000&rate=0&months=10');
    assert.equal(data.emi, 5000);
    const r = await api('GET', '/api/emi?price=100000&down=0&rate=12&months=12');
    assert.equal(r.data.emi, 8885);
    assert.equal((await api('GET', '/api/emi?price=1000&down=5000&months=3')).status, 400);
  });

  let shopToken;
  await t('shop OTP login', async () => {
    assert.equal((await api('POST', '/api/auth/otp/request', { phone: '123' })).status, 400);
    const req = await api('POST', '/api/auth/otp/request', { phone: '9000000001' });
    assert.ok(req.data.devOtp);
    assert.equal((await api('POST', '/api/auth/otp/verify', { phone: '9000000001', otp: '000000' })).status, 400);
    const ok = await api('POST', '/api/auth/otp/verify', { phone: '9000000001', otp: req.data.devOtp });
    assert.equal(ok.status, 200);
    shopToken = ok.data.token;
  });

  await t('auth required', async () => {
    assert.equal((await api('GET', '/api/shop/me')).status, 401);
    assert.equal((await api('GET', '/api/shop/me', null, 'garbage.token')).status, 401);
  });

  await t('shop edits own listing; change shows in search', async () => {
    const me = await api('GET', '/api/shop/me', null, shopToken);
    assert.equal(me.data.shop.name, 'Tech Bazaar');
    const l = me.data.listings[0];
    const up = await api('PUT', '/api/shop/listings/' + l.id, { price: 1111, stock: 3, freebies: 'Case, Glass' }, shopToken);
    assert.equal(up.data.listing.price, 1111);
    assert.deepEqual(up.data.listing.freebies, ['Case', 'Glass']);
    assert.equal((await api('PUT', '/api/shop/listings/' + l.id, { price: -5 }, shopToken)).status, 400);
    const s = await api('GET', '/api/search?q=' + encodeURIComponent(l.productName.split(' ')[0]));
    assert.ok(JSON.stringify(s.data).includes('"price":1111'));
  });

  await t("shop cannot edit another shop's listing", async () => {
    const other = await api('GET', '/api/search?q=redmi');
    const foreign = other.data.results[0].listings.find((x) => x.shop.id !== 's1');
    assert.equal((await api('PUT', '/api/shop/listings/' + foreign.id, { price: 1 }, shopToken)).status, 404);
  });

  let adminToken;
  await t('signup -> pending -> cannot login -> admin approves -> can login', async () => {
    const su = await api('POST', '/api/shops/signup', { name: 'New Shop', phone: '9876543210', area: 'ammapet' });
    assert.equal(su.status, 200);
    assert.equal((await api('POST', '/api/shops/signup', { name: 'Dup', phone: '9876543210', area: 'ammapet' })).status, 409);

    const o1 = await api('POST', '/api/auth/otp/request', { phone: '9876543210' });
    assert.equal((await api('POST', '/api/auth/otp/verify', { phone: '9876543210', otp: o1.data.devOtp })).status, 403);

    assert.equal((await api('POST', '/api/admin/login', { password: 'nope' })).status, 401);
    adminToken = (await api('POST', '/api/admin/login', { password: 'testpass' })).data.token;
    assert.equal((await api('GET', '/api/admin/shops', null, shopToken)).status, 401); // shop token is not admin
    assert.equal((await api('POST', `/api/admin/shops/${su.data.id}/approve`, null, adminToken)).status, 200);

    // OTP was consumed by the first verify, so request a new one (rate limit is 30s -> clear by new phone state)
    const again = await api('POST', '/api/auth/otp/request', { phone: '9876543210' });
    assert.equal(again.status, 429); // proves the rate limiter works
  });

  await t('static + traversal guard', async () => {
    const r = await fetch(base + '/..%2f..%2fserver.js');
    assert.ok([403, 404].includes(r.status));
  });

  console.log(`\n${passed} tests passed`);
  server.close();
  process.exit(0);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
