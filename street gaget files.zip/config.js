// Where is the backend?
//  - Backend serves this frontend too (npm start)  -> leave as ''  (same origin)
//  - Frontend on Netlify, backend elsewhere        -> 'https://your-backend.onrender.com'
//    (and set CORS_ORIGIN on the backend to your Netlify URL)
window.GS_CONFIG = { API_BASE: '' };
