'use strict';
// Tiny JSON-file "database". Fine for a prototype / single server.
// For production swap this for Supabase/Postgres: the rest of the app only touches store.db and store.save().
const fs = require('fs');
const path = require('path');
const { buildSeed } = require('../data/seed');

const FILE = process.env.DB_FILE || path.join(__dirname, '..', 'data', 'db.json');
let db = null;

function writeFile() {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, FILE); // atomic replace
}

function save() {
  try { writeFile(); } catch (e) { console.warn('DB save failed (read-only disk?):', e.message); }
}

function load() {
  try {
    db = JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    db = buildSeed();
    save();
  }
  return db;
}

function nextId(prefix) {
  const d = module.exports.db;
  d.counters = d.counters || {};
  d.counters[prefix] = (d.counters[prefix] || 1000) + 1;
  return prefix[0] + d.counters[prefix];
}

module.exports = {
  get db() { return db || load(); },
  save,
  reset() { db = buildSeed(); save(); },
  nextId,
};
