(() => {
  'use strict';

  /* ------------------------------------------------------------ helpers */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const inr = (n) => '₹' + Number(n).toLocaleString('en-IN');
  const API = (window.GS_CONFIG && window.GS_CONFIG.API_BASE) || '';

  const store = {
    get: (k) => { try { return sessionStorage.getItem(k) || localStorage.getItem(k); } catch { return null; } },
    setSession: (k, v) => { try { v ? sessionStorage.setItem(k, v) : sessionStorage.removeItem(k); } catch { /* private mode */ } },
    setLocal: (k, v) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } },
  };

  const state = {
    lang: store.get('gs_lang') === 'ta' ? 'ta' : 'en',
    view: 'customer',
    loc: null,            // { lat, lng } when "Use my location" is on
    areas: [],
    device: 'phone',
    budget: 30000,
    shopToken: store.get('gs_shop'),
    adminToken: null,
  };

  const t = (k, vars = {}) => {
    let s = (I18N[state.lang] && I18N[state.lang][k]) || I18N.en[k] || k;
    for (const [a, b] of Object.entries(vars)) s = s.replace(`{${a}}`, b);
    return s;
  };

  let toastTimer;
  function toast(msg, isErr = false) {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'show' + (isErr ? ' err' : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (el.className = ''), 3000);
  }

  async function api(path, { method = 'GET', body, token } = {}) {
    let res;
    try {
      res = await fetch(API + path, {
        method,
        headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: 'Bearer ' + token } : {}) },
        body: body ? JSON.stringify(body) : undefined,
      });
    } catch { throw new Error(t('err_generic')); }
    let data = {};
    try { data = await res.json(); } catch { /* empty */ }
    if (!res.ok) { const e = new Error(data.error || t('err_generic')); e.status = res.status; throw e; }
    return data;
  }

  const debounce = (fn, ms = 300) => { let id; return (...a) => { clearTimeout(id); id = setTimeout(() => fn(...a), ms); }; };

  function timeAgo(iso) {
    const diff = (new Date(iso).getTime() - Date.now()) / 1000;
    const rtf = new Intl.RelativeTimeFormat(state.lang === 'ta' ? 'ta' : 'en', { numeric: 'auto' });
    const abs = Math.abs(diff);
    if (abs < 3600) return rtf.format(Math.round(diff / 60), 'minute');
    if (abs < 86400) return rtf.format(Math.round(diff / 3600), 'hour');
    return rtf.format(Math.round(diff / 86400), 'day');
  }

  const geoParams = () => (state.loc ? `&lat=${state.loc.lat}&lng=${state.loc.lng}` : '');

  /* --------------------------------------------------------------- i18n */
  function applyLang() {
    document.documentElement.lang = state.lang;
    $$('[data-i18n]').forEach((el) => { el.innerHTML = t(el.dataset.i18n); });
    $$('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
    $('#langBtn').textContent = state.lang === 'en' ? 'தமிழ்' : 'English';
    $('#locBtn').textContent = state.loc ? t('location_on') : t('use_location');
    fillAreaSelects();
    renderDeviceChips();
    renderBudgetChips();
    renderEmi();
  }

  /* ---------------------------------------------------------------- nav */
  function showView(v) {
    state.view = v;
    $$('.view').forEach((el) => el.classList.toggle('active', el.id === 'view-' + v));
    $$('#nav .pill').forEach((b) => b.classList.toggle('active', b.dataset.view === v));
    if (location.hash !== '#' + v) history.replaceState(null, '', '#' + v);
    if (v === 'customer') runSearch();
    if (v === 'repair') loadRepairs();
    if (v === 'budget') loadBudget();
    if (v === 'shop') renderShop();
  }

  /* ------------------------------------------------------------- areas */
  function fillAreaSelects() {
    for (const id of ['area', 'repairArea']) {
      const sel = $('#' + id);
      const cur = sel.value;
      sel.innerHTML = `<option value="">${esc(t('all_areas'))}</option>` +
        state.areas.map((a) => `<option value="${esc(a.id)}">${esc(state.lang === 'ta' ? a.ta : a.name)}</option>`).join('');
      sel.value = cur;
    }
  }

  /* ----------------------------------------------------------- customer */
  let searchSeq = 0;
  async function runSearch() {
    const q = $('#q').value.trim();
    const box = $('#results');
    const seq = ++searchSeq;
    box.innerHTML = `<p class="loading">${esc(t('searching'))}</p>`;
    try {
      const data = await api(`/api/search?q=${encodeURIComponent(q)}&sort=${$('#sort').value}&area=${encodeURIComponent($('#area').value)}${geoParams()}`);
      if (seq !== searchSeq) return; // a newer search is in flight
      let groups = data.results;
      if (!q) groups = groups.slice(0, 3);
      if (!groups.length) { box.innerHTML = `<p class="empty">${esc(t('no_results'))}</p>`; return; }
      box.innerHTML = (q ? '' : `<div class="section-title">${esc(t('popular'))}</div>`) + groups.map(groupHtml).join('');
    } catch (e) {
      if (seq === searchSeq) box.innerHTML = `<p class="empty">${esc(e.message)}</p>`;
    }
  }

  function contactButtons(l, { emiBtn = true } = {}) {
    const msg = encodeURIComponent(`Hi ${l.shop.name}, is the ${l.productName} available at ${inr(l.price)}? (Seen on Gadget Street)`);
    return `
      <a class="btn primary" href="tel:+91${esc(l.shop.phone)}">📞 ${esc(t('call'))}</a>
      <a class="btn wa" target="_blank" rel="noopener" href="https://wa.me/${esc(l.shop.whatsapp)}?text=${msg}">💬 ${esc(t('whatsapp'))}</a>
      <a class="btn" target="_blank" rel="noopener" href="${esc(l.shop.mapUrl)}">📍 ${esc(t('map'))}</a>
      ${emiBtn ? `<button class="btn" type="button" data-emi="${l.price}">🧮 ${esc(t('emi_link'))}</button>` : ''}`;
  }

  function listingHtml(l, isBest) {
    const stockTag = !l.inStock ? `<span class="tag bad">${esc(t('out_stock'))}</span>`
      : l.stock <= 3 ? `<span class="tag warn">${esc(t('few_left', { n: l.stock }))}</span>`
      : `<span class="tag ok">${esc(t('in_stock'))}</span>`;
    return `
      <article class="listing ${isBest ? 'best' : ''}">
        <div class="l-top">
          <div><h4>${esc(l.shop.name)}</h4><div class="sub">${esc(l.shop.areaName)} • ${l.distanceKm} ${esc(t('km_away'))}</div></div>
          <div class="price"><b>${inr(l.price)}</b>${l.discountPct ? `<s>${inr(l.mrp)}</s><em>${l.discountPct}% ${esc(t('off'))}</em>` : ''}</div>
        </div>
        <div class="tags">
          ${stockTag}
          ${l.emi ? `<span class="tag">💳 ${esc(l.emi)}</span>` : ''}
          ${l.freebies.map((f) => `<span class="tag">🎁 ${esc(f)}</span>`).join('')}
        </div>
        <div class="actions">${contactButtons(l)}</div>
        <div class="updated">${esc(t('updated'))} ${esc(timeAgo(l.updatedAt))}</div>
      </article>`;
  }

  function groupHtml(g) {
    const inStock = g.listings.filter((l) => l.inStock);
    const max = g.stats.highest || 1;
    const bars = inStock.slice(0, 5).map((l) => `
      <div class="bar-row ${l.price === g.stats.lowest ? 'best' : ''}">
        <span class="name">${esc(l.shop.name)}</span>
        <span class="bar"><i style="width:${Math.max(18, Math.round((l.price / max) * 100))}%"></i></span>
        <b>${inr(l.price)}</b>
      </div>`).join('');
    const saving = g.stats.highest && g.stats.lowest ? g.stats.highest - g.stats.lowest : 0;
    return `
      <section class="group">
        <div class="group-head">
          <h3>${esc(g.product.name)}</h3>
          <span class="muted small">${g.stats.shops} ${esc(t('shops'))}</span>
          ${saving > 0 ? `<span class="save-tag">${esc(t('save_up_to'))} ${inr(saving)}</span>` : ''}
        </div>
        ${bars ? `<div class="bars"><h4>${esc(t('price_comparison'))}</h4>${bars}</div>` : ''}
        ${g.listings.map((l) => listingHtml(l, l.inStock && l.price === g.stats.lowest)).join('')}
        <p class="muted small">${esc(t('sample'))}</p>
      </section>`;
  }

  /* -------------------------------------------------------- EMI (client) */
  function renderEmi() {
    const price = +$('#emiPrice').value || 0;
    const down = Math.min(+$('#emiDown').value || 0, price);
    const rate = Math.max(0, +$('#emiRate').value || 0);
    const n = +$('#emiMonths').value;
    const principal = price - down;
    let emi = 0;
    if (principal > 0) {
      const r = rate / 12 / 100;
      emi = r === 0 ? principal / n : (principal * r * (1 + r) ** n) / ((1 + r) ** n - 1);
    }
    const interest = emi * n - principal;
    $('#emiOut').innerHTML = `
      <div><b>${inr(Math.round(emi))}</b><span>${esc(t('emi_monthly'))} × ${n}</span></div>
      <div><b>${inr(Math.max(0, Math.round(interest)))}</b><span>${esc(t('emi_interest'))}</span></div>
      <div><b>${inr(Math.round(down + emi * n))}</b><span>${esc(t('emi_total'))}</span></div>`;
  }

  /* ----------------------------------------------------- voice assistant */
  function setupVoice() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const btn = $('#micBtn');
    if (!SR) { btn.addEventListener('click', () => toast(t('err_voice'), true)); return; }
    let rec = null;
    btn.addEventListener('click', () => {
      if (rec) { rec.stop(); return; }
      rec = new SR();
      rec.lang = state.lang === 'ta' ? 'ta-IN' : 'en-IN';
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      btn.classList.add('listening');
      toast(t('listening'));
      rec.onresult = (ev) => {
        $('#q').value = ev.results[0][0].transcript.replace(/[.?!]+$/, '');
        showView('customer');
        runSearch();
      };
      rec.onerror = () => toast(t('err_voice'), true);
      rec.onend = () => { btn.classList.remove('listening'); rec = null; };
      try { rec.start(); } catch { rec = null; btn.classList.remove('listening'); }
    });
  }

  /* -------------------------------------------------------------- repair */
  const DEVICES = [['phone', '📱'], ['laptop', '💻'], ['tv', '📺'], ['watch', '⌚'], ['earbuds', '🎧']];
  function renderDeviceChips() {
    $('#deviceChips').innerHTML = DEVICES.map(([id, ic]) =>
      `<button class="chip ${state.device === id ? 'active' : ''}" type="button" data-device="${id}">${ic} ${esc(t('dev_' + id))}</button>`).join('');
  }

  async function loadRepairs() {
    const box = $('#repairResults');
    box.innerHTML = `<p class="loading">${esc(t('searching'))}</p>`;
    try {
      const data = await api(`/api/repairs?device=${state.device}&area=${encodeURIComponent($('#repairArea').value)}${geoParams()}`);
      if (!data.shops.length) { box.innerHTML = `<p class="empty">${esc(t('no_repair'))}</p>`; return; }
      box.innerHTML = data.shops.map((r) => `
        <article class="listing">
          <div class="l-top">
            <div><h4>${esc(r.name)}</h4><div class="sub">${esc(r.areaName)} • ${r.distanceKm} ${esc(t('km_away'))}</div></div>
            <div class="price"><small class="muted">${esc(t('starting_at'))}</small><b>${inr(r.startingPrice)}</b></div>
          </div>
          <div class="tags"><span class="tag">⏱ ${esc(t('turnaround'))}: ${esc(r.turnaround)}</span><span class="tag">🛡 ${esc(t('warranty'))}: ${esc(r.warranty)}</span></div>
          <div class="actions">
            <a class="btn primary" href="tel:+91${esc(r.phone)}">📞 ${esc(t('call'))}</a>
            <a class="btn wa" target="_blank" rel="noopener" href="https://wa.me/${esc(r.whatsapp)}">💬 ${esc(t('whatsapp'))}</a>
            <a class="btn" target="_blank" rel="noopener" href="${esc(r.mapUrl)}">📍 ${esc(t('map'))}</a>
          </div>
        </article>`).join('') + `<p class="empty small">${esc(data.note)}</p>`;
    } catch (e) { box.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
  }

  /* -------------------------------------------------------------- budget */
  const PRESETS = [15000, 20000, 30000, 50000, 80000];
  function renderBudgetChips() {
    $('#budgetChips').innerHTML = PRESETS.map((n) =>
      `<button class="chip ${state.budget === n ? 'active' : ''}" type="button" data-budget="${n}">${inr(n)}</button>`).join('');
  }

  async function loadBudget() {
    const box = $('#budgetResults');
    const amount = +$('#budgetAmount').value;
    if (!amount || amount < 500) { box.innerHTML = ''; return; }
    box.innerHTML = `<p class="loading">${esc(t('searching'))}</p>`;
    try {
      const data = await api(`/api/budget?amount=${amount}&priority=${$('#budgetPriority').value}${geoParams()}`);
      if (!data.picks.length) { box.innerHTML = `<p class="empty">${esc(t('no_budget'))}</p>`; return; }
      box.innerHTML = data.picks.map((p, i) => `
        <article class="listing ${i === 0 ? 'best' : ''}">
          <div class="l-top">
            <div><h4>#${i + 1} ${esc(p.best.productName)}</h4><div class="sub">${esc(p.best.shop.name)} • ${esc(p.best.shop.areaName)}</div></div>
            <div class="price"><b>${inr(p.best.price)}</b>${p.best.discountPct ? `<s>${inr(p.best.mrp)}</s><em>${p.best.discountPct}% ${esc(t('off'))}</em>` : ''}</div>
          </div>
          <div class="tags"><span class="tag ok">${esc(p.reason)}</span>${p.best.emi ? `<span class="tag">💳 ${esc(p.best.emi)}</span>` : ''}${p.otherShops ? `<span class="tag">${esc(t('other_shops', { n: p.otherShops }))}</span>` : ''}</div>
          <div class="actions">
            ${contactButtons(p.best, { emiBtn: false })}
            <button class="btn" type="button" data-compare="${esc(p.best.productName)}">⚖ ${esc(t('compare_shops'))}</button>
          </div>
        </article>`).join('');
    } catch (e) { box.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
  }

  /* ------------------------------------------------------ shop dashboard */
  function shopAuthHtml(mode = 'login') {
    const areaOpts = state.areas.map((a) => `<option value="${esc(a.id)}">${esc(state.lang === 'ta' ? a.ta : a.name)}</option>`).join('');
    return `
      <div class="card">
        <div class="tabs">
          <button class="chip ${mode === 'login' ? 'active' : ''}" type="button" data-shopmode="login">${esc(t('tab_login'))}</button>
          <button class="chip ${mode === 'signup' ? 'active' : ''}" type="button" data-shopmode="signup">${esc(t('tab_signup'))}</button>
        </div>
        ${mode === 'login' ? `
          <div class="form-grid">
            <label><span>${esc(t('mobile'))}</span><input id="shopPhone" type="tel" inputmode="numeric" maxlength="14" placeholder="9000000001"></label>
            <button class="btn primary" type="button" data-act="otp-send">${esc(t('send_otp'))}</button>
            <div id="otpStep" hidden class="form-grid">
              <div id="otpHint"></div>
              <label><span>${esc(t('otp'))}</span><input id="shopOtp" type="text" inputmode="numeric" maxlength="6" autocomplete="one-time-code"></label>
              <button class="btn primary" type="button" data-act="otp-verify">${esc(t('verify'))}</button>
            </div>
          </div>` : `
          <div class="form-grid">
            <label><span>${esc(t('shop_name'))}</span><input id="suName" maxlength="60"></label>
            <label><span>${esc(t('mobile'))}</span><input id="suPhone" type="tel" inputmode="numeric" maxlength="14"></label>
            <label><span>${esc(t('area'))}</span><select id="suArea">${areaOpts}</select></label>
            <button class="btn primary" type="button" data-act="signup">${esc(t('submit'))}</button>
          </div>`}
      </div>`;
  }

  async function renderShop(mode) {
    const root = $('#shopRoot');
    if (!state.shopToken) { root.innerHTML = shopAuthHtml(mode); return; }
    root.innerHTML = `<p class="loading">${esc(t('searching'))}</p>`;
    try {
      const [me, catalog] = await Promise.all([
        api('/api/shop/me', { token: state.shopToken }),
        api('/api/catalog'),
      ]);
      const listed = new Set(me.listings.map((l) => l.productId));
      const addable = catalog.products.filter((p) => !listed.has(p.id));
      root.innerHTML = `
        <div class="card row-between"><div><h3>${esc(me.shop.name)}</h3><span class="muted small">${esc(me.shop.phone)}</span></div>
          <button class="btn" type="button" data-act="logout">${esc(t('logout'))}</button></div>
        <div class="section-title">${esc(t('your_products'))} (${me.listings.length})</div>
        ${me.listings.length ? me.listings.map(editRowHtml).join('') : `<p class="empty">${esc(t('no_listings'))}</p>`}
        <div class="card">
          <h3>${esc(t('add_product'))}</h3>
          <div class="listing-edit">
            <label class="wide"><span>${esc(t('choose_product'))}</span>
              <select id="addProduct">${addable.map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select></label>
            <label><span>${esc(t('price'))}</span><input id="addPrice" type="number" min="1" inputmode="numeric"></label>
            <label><span>${esc(t('stock'))}</span><input id="addStock" type="number" min="0" value="1" inputmode="numeric"></label>
          </div>
          <p><button class="btn primary" type="button" data-act="add-listing" ${addable.length ? '' : 'disabled'}>${esc(t('add'))}</button></p>
        </div>`;
    } catch (e) {
      if (e.status === 401) { state.shopToken = null; store.setSession('gs_shop', null); renderShop(); return; }
      root.innerHTML = `<p class="empty">${esc(e.message)}</p>`;
    }
  }

  function editRowHtml(l) {
    return `
      <article class="listing" data-id="${esc(l.id)}">
        <div class="row-between"><h4>${esc(l.productName)}</h4><span class="muted small">MRP ${inr(l.mrp)}</span></div>
        <div class="listing-edit">
          <label><span>${esc(t('price'))}</span><input data-f="price" type="number" min="1" inputmode="numeric" value="${l.price}"></label>
          <label><span>${esc(t('stock'))}</span><input data-f="stock" type="number" min="0" inputmode="numeric" value="${l.stock}"></label>
          <label class="wide"><span>${esc(t('emi_offer'))}</span><input data-f="emi" maxlength="80" value="${esc(l.emi)}"></label>
          <label class="wide"><span>${esc(t('freebies'))}</span><input data-f="freebies" value="${esc(l.freebies.join(', '))}"></label>
        </div>
        <div class="actions" style="margin-top:10px">
          <button class="btn primary" type="button" data-act="save-listing">${esc(t('save'))}</button>
          <button class="btn danger" type="button" data-act="delete-listing">${esc(t('delete'))}</button>
        </div>
      </article>`;
  }

  async function shopAction(btn) {
    const act = btn.dataset.act;
    try {
      if (act === 'otp-send') {
        const phone = $('#shopPhone').value;
        const r = await api('/api/auth/otp/request', { method: 'POST', body: { phone } });
        $('#otpStep').hidden = false;
        $('#otpHint').innerHTML = r.devOtp ? `<div class="hint">${esc(t('demo_otp'))}: <b>${esc(r.devOtp)}</b></div>` : '';
        $('#shopOtp').focus();
      } else if (act === 'otp-verify') {
        const r = await api('/api/auth/otp/verify', { method: 'POST', body: { phone: $('#shopPhone').value, otp: $('#shopOtp').value } });
        state.shopToken = r.token;
        store.setSession('gs_shop', r.token);
        renderShop();
      } else if (act === 'signup') {
        await api('/api/shops/signup', { method: 'POST', body: { name: $('#suName').value, phone: $('#suPhone').value, area: $('#suArea').value } });
        toast(t('signup_done'));
        renderShop('login');
      } else if (act === 'logout') {
        state.shopToken = null; store.setSession('gs_shop', null); renderShop();
      } else if (act === 'save-listing') {
        const row = btn.closest('[data-id]');
        const body = {};
        $$('[data-f]', row).forEach((i) => (body[i.dataset.f] = i.value));
        await api('/api/shop/listings/' + row.dataset.id, { method: 'PUT', body, token: state.shopToken });
        toast(t('saved'));
      } else if (act === 'delete-listing') {
        if (!confirm(t('confirm_delete'))) return;
        await api('/api/shop/listings/' + btn.closest('[data-id]').dataset.id, { method: 'DELETE', token: state.shopToken });
        toast(t('deleted'));
        renderShop();
      } else if (act === 'add-listing') {
        await api('/api/shop/listings', { method: 'POST', token: state.shopToken,
          body: { productId: $('#addProduct').value, price: $('#addPrice').value, stock: $('#addStock').value } });
        toast(t('saved'));
        renderShop();
      }
    } catch (e) {
      if (e.status === 401 && state.shopToken) { state.shopToken = null; store.setSession('gs_shop', null); renderShop(); }
      toast(e.message, true);
    }
  }

  /* --------------------------------------------------------------- admin */
  async function renderAdmin() {
    const body = $('#adminBody');
    if (!state.adminToken) {
      body.innerHTML = `<div class="form-grid">
        <label><span>${esc(t('password'))}</span><input id="adminPw" type="password" autocomplete="current-password"></label>
        <button class="btn primary" type="button" data-adm="login">${esc(t('login'))}</button></div>`;
      return;
    }
    try {
      const { shops } = await api('/api/admin/shops', { token: state.adminToken });
      body.innerHTML = shops.map((s) => `
        <div class="admin-shop" data-id="${esc(s.id)}">
          <div><b>${esc(s.name)}</b><div class="muted small">${esc(s.areaName)} • ${esc(s.phone)} • ${esc(t(s.status))}</div></div>
          <div class="actions">
            ${s.status !== 'approved' ? `<button class="btn primary" data-adm="approve">${esc(t('approve'))}</button>` : ''}
            ${s.status !== 'rejected' ? `<button class="btn danger" data-adm="reject">${esc(t('reject'))}</button>` : ''}
          </div>
        </div>`).join('');
    } catch (e) { state.adminToken = null; toast(e.message, true); renderAdmin(); }
  }

  /* -------------------------------------------------------------- events */
  function bind() {
    $('#nav').addEventListener('click', (e) => { const b = e.target.closest('[data-view]'); if (b) showView(b.dataset.view); });
    $('#langBtn').addEventListener('click', () => {
      state.lang = state.lang === 'en' ? 'ta' : 'en';
      store.setLocal('gs_lang', state.lang);
      applyLang();
      showView(state.view);
    });

    const search = debounce(runSearch, 350);
    $('#q').addEventListener('input', search);
    $('#q').addEventListener('keydown', (e) => { if (e.key === 'Enter') runSearch(); });
    $('#sort').addEventListener('change', runSearch);
    $('#area').addEventListener('change', runSearch);

    $('#locBtn').addEventListener('click', () => {
      if (state.loc) { state.loc = null; applyLang(); runSearch(); return; }
      if (!navigator.geolocation) return toast(t('err_loc'), true);
      navigator.geolocation.getCurrentPosition(
        (p) => { state.loc = { lat: p.coords.latitude, lng: p.coords.longitude }; $('#sort').value = 'nearest'; applyLang(); showView(state.view); },
        () => toast(t('err_loc'), true),
        { enableHighAccuracy: false, timeout: 8000 });
    });

    ['emiPrice', 'emiDown', 'emiRate', 'emiMonths'].forEach((id) => $('#' + id).addEventListener('input', renderEmi));
    $('#emiNoCost').addEventListener('click', () => { $('#emiRate').value = 0; renderEmi(); });

    // Delegated clicks for dynamically rendered content
    document.addEventListener('click', (e) => {
      const emiBtn = e.target.closest('[data-emi]');
      if (emiBtn) {
        showView('customer');
        $('#emiPrice').value = emiBtn.dataset.emi;
        $('#emiBox').open = true;
        renderEmi();
        $('#emiBox').scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      const cmp = e.target.closest('[data-compare]');
      if (cmp) { $('#q').value = cmp.dataset.compare; showView('customer'); window.scrollTo({ top: 0, behavior: 'smooth' }); return; }
      const dev = e.target.closest('[data-device]');
      if (dev) { state.device = dev.dataset.device; renderDeviceChips(); loadRepairs(); return; }
      const bud = e.target.closest('[data-budget]');
      if (bud) { state.budget = +bud.dataset.budget; $('#budgetAmount').value = state.budget; renderBudgetChips(); loadBudget(); return; }
      const mode = e.target.closest('[data-shopmode]');
      if (mode) { renderShop(mode.dataset.shopmode); return; }
      const act = e.target.closest('#shopRoot [data-act]');
      if (act) shopAction(act);
    });

    $('#repairArea').addEventListener('change', loadRepairs);
    $('#budgetPriority').addEventListener('change', loadBudget);
    $('#budgetAmount').addEventListener('input', debounce(() => {
      state.budget = +$('#budgetAmount').value; renderBudgetChips(); loadBudget();
    }, 400));

    $('#adminLink').addEventListener('click', (e) => { e.preventDefault(); $('#adminDlg').showModal(); renderAdmin(); });
    $('#adminClose').addEventListener('click', () => $('#adminDlg').close());
    $('#adminBody').addEventListener('click', async (e) => {
      const b = e.target.closest('[data-adm]');
      if (!b) return;
      try {
        if (b.dataset.adm === 'login') {
          const r = await api('/api/admin/login', { method: 'POST', body: { password: $('#adminPw').value } });
          state.adminToken = r.token;
        } else {
          await api(`/api/admin/shops/${b.closest('[data-id]').dataset.id}/${b.dataset.adm}`, { method: 'POST', token: state.adminToken });
        }
        renderAdmin();
      } catch (err) { toast(err.message, true); }
    });
  }

  /* ---------------------------------------------------------------- boot */
  async function init() {
    bind();
    setupVoice();
    try { state.areas = (await api('/api/areas')).areas; } catch { toast(t('err_generic'), true); }
    applyLang();
    const start = location.hash.slice(1);
    showView(['customer', 'shop', 'repair', 'budget'].includes(start) ? start : 'customer');
  }
  init();
})();
