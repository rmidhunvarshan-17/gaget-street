'use strict';
// Sample data only - NOT live prices. Deterministic so every fresh start looks the same.

const AREAS = [
  { id: 'junction', name: 'Salem Junction', ta: 'சேலம் ஜங்ஷன்', lat: 11.6643, lng: 78.146 },
  { id: 'fairlands', name: 'Fairlands', ta: 'ஃபேர்லேண்ட்ஸ்', lat: 11.6765, lng: 78.138 },
  { id: 'five-roads', name: 'Five Roads', ta: 'ஐந்து ரோடு', lat: 11.6712, lng: 78.1527 },
  { id: 'hasthampatti', name: 'Hasthampatti', ta: 'ஹஸ்தம்பட்டி', lat: 11.6805, lng: 78.1692 },
  { id: 'ammapet', name: 'Ammapet', ta: 'அம்மாபேட்டை', lat: 11.6531, lng: 78.1736 },
  { id: 'shevapet', name: 'Shevapet', ta: 'செவ்வாய்ப்பேட்டை', lat: 11.6578, lng: 78.1589 },
];

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const SHOPS = [
  ['Tech Bazaar', 'junction', '9000000001'],
  ['Sri Murugan Electronics', 'five-roads', '9000000002'],
  ['Salem Mobile Hub', 'fairlands', '9000000003'],
  ['Digital Palace', 'hasthampatti', '9000000004'],
  ['Gadget Zone', 'ammapet', '9000000005'],
  ['Kavin Communications', 'shevapet', '9000000006'],
  ['Annapoorani Digital World', 'junction', '9000000007'],
  ['Star Mobiles & Laptops', 'fairlands', '9000000008'],
];

const PRODUCTS = [
  ['iPhone 16 128GB', 'Apple', 'phone', 79900, ['ஐபோன்', 'mobile', 'மொபைல்', 'smartphone']],
  ['Samsung Galaxy S24 256GB', 'Samsung', 'phone', 74999, ['சாம்சங்', 'mobile', 'மொபைல்']],
  ['OnePlus 12R 256GB', 'OnePlus', 'phone', 42999, ['ஒன்பிளஸ்', 'mobile', 'மொபைல்']],
  ['Redmi Note 13 Pro 8GB/256GB', 'Xiaomi', 'phone', 26999, ['ரெட்மி', 'mi', 'mobile', 'மொபைல்']],
  ['Realme 12 Pro 5G', 'Realme', 'phone', 29999, ['ரியல்மி', 'mobile', 'மொபைல்']],
  ['Vivo V30 5G', 'Vivo', 'phone', 33999, ['விவோ', 'mobile', 'மொபைல்']],
  ['HP Pavilion 15 Ryzen 5', 'HP', 'laptop', 58990, ['லேப்டாப்', 'notebook', 'கணினி']],
  ['Lenovo IdeaPad Slim 3 i5', 'Lenovo', 'laptop', 56990, ['லேப்டாப்', 'notebook', 'கணினி']],
  ['Sony Bravia 43" 4K Smart TV', 'Sony', 'tv', 52990, ['டிவி', 'television', 'தொலைக்காட்சி']],
  ['Samsung 43" Crystal 4K TV', 'Samsung', 'tv', 36990, ['டிவி', 'television', 'தொலைக்காட்சி']],
  ['boAt Airdopes 141 Earbuds', 'boAt', 'earbuds', 2990, ['இயர்பட்ஸ்', 'earphones', 'ஹெட்போன்']],
  ['Noise ColorFit Pro 4 Smartwatch', 'Noise', 'watch', 4999, ['வாட்ச்', 'smartwatch', 'கடிகாரம்']],
];

const FREEBIES = {
  phone: ['Free back case', 'Tempered glass', 'Free earbuds', '1-yr screen insurance', 'Free delivery'],
  laptop: ['Free backpack', 'Wireless mouse', 'Free Office setup', '1-yr accidental cover'],
  tv: ['Free wall-mount fitting', 'Free HDMI cable', 'Free delivery & install'],
  earbuds: ['Free pouch', 'Free delivery'],
  watch: ['Extra strap', 'Free delivery'],
};

function buildSeed() {
  const rand = mulberry32(2024);
  const shops = SHOPS.map(([name, area, phone], i) => {
    const a = AREAS.find((x) => x.id === area);
    return {
      id: 's' + (i + 1), name, area, phone, whatsapp: '91' + phone,
      lat: +(a.lat + (rand() - 0.5) * 0.006).toFixed(5),
      lng: +(a.lng + (rand() - 0.5) * 0.006).toFixed(5),
      status: 'approved', createdAt: new Date('2025-01-01').toISOString(),
    };
  });

  const products = PRODUCTS.map(([name, brand, category, mrp, aliases], i) => ({
    id: 'p' + (i + 1), name, brand, category, mrp, aliases,
  }));

  const emiOptions = [
    'No-cost EMI 6 months', 'No-cost EMI 3 months', '9 months @ 12%', 'Bajaj Finserv EMI available', 'Debit-card EMI',
  ];
  const listings = [];
  let n = 1;
  for (const p of products) {
    for (const s of shops) {
      if (rand() < 0.2) continue; // not every shop stocks everything
      const price = Math.round((p.mrp * (0.86 + rand() * 0.12)) / 10) * 10;
      const stock = rand() < 0.15 ? 0 : 1 + Math.floor(rand() * 12);
      const freebies = FREEBIES[p.category].filter(() => rand() < 0.4).slice(0, 3);
      listings.push({
        id: 'l' + n++, shopId: s.id, productId: p.id, price, stock,
        emi: emiOptions[Math.floor(rand() * emiOptions.length)],
        freebies, updatedAt: new Date().toISOString(),
      });
    }
  }

  const repairShops = [
    ['QuickFix Mobile Care', 'junction', '9100000001', ['phone', 'earbuds', 'watch'], { phone: 299, earbuds: 199, watch: 349 }, 'Same day', '3 months'],
    ['Salem Laptop Clinic', 'five-roads', '9100000002', ['laptop'], { laptop: 599 }, '1-2 days', '6 months'],
    ['Screen Doctor', 'fairlands', '9100000003', ['phone', 'watch'], { phone: 349, watch: 399 }, '2 hours', '3 months'],
    ['TV & Display Service Centre', 'hasthampatti', '9100000004', ['tv'], { tv: 799 }, '2-3 days', '3 months'],
    ['All-in-One Repair Point', 'ammapet', '9100000005', ['phone', 'laptop', 'tv', 'watch', 'earbuds'], { phone: 249, laptop: 499, tv: 699, watch: 299, earbuds: 149 }, '1-3 days', '1-3 months'],
    ['Kavin Mobile Service', 'shevapet', '9100000006', ['phone', 'earbuds'], { phone: 279, earbuds: 129 }, 'Same day', '1 month'],
  ].map(([name, area, phone, devices, startingPrice, turnaround, warranty], i) => {
    const a = AREAS.find((x) => x.id === area);
    return {
      id: 'r' + (i + 1), name, area, phone, whatsapp: '91' + phone, devices, startingPrice, turnaround, warranty,
      lat: +(a.lat + (rand() - 0.5) * 0.006).toFixed(5),
      lng: +(a.lng + (rand() - 0.5) * 0.006).toFixed(5),
    };
  });

  return { areas: AREAS, shops, products, listings, repairShops, counters: { listing: 1000, shop: 1000 } };
}

module.exports = { buildSeed, AREAS };
