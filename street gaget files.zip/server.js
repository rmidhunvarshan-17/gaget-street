'use strict';
/**
 * Gadget Street API - zero dependencies (Node 18+).
 * Run:  node server.js      ->  http://localhost:3000   (also serves ../frontend)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const store = require('./lib/store');
const { CITY_CENTRE, haversineKm, discountPct, emiCalc, normalisePhone, num } = require('./lib/util');

const PORT = process.env.PORT || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';
const SECRET = process.env.TOKEN_SECRET || crypto.randomBytes(32).toString('hex');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

if (IS_PROD && (!process.env.TOKEN_SECRET || !process.env.ADMIN_PASSWORD)) {
  console.warn('WARNING: set TOKEN_SECRET and ADMIN_PASSWORD in production.');
}

/* ---------------------------------------------------------------- helpers */
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (m) => new HttpError(400, m);

const db = () => store.db;
const shopById = (id) => db().shops.find((s) => s.id === id);
const productById = (id) => db().products.find((p) => p.id === id);
const areaById = (id) => db().areas.find((a) => a.id === id);

function mapUrl(o) {
  return `https://www.google.com/maps/search/?api=1&query=${o.lat},${o.lng}`;
}

function parseOrigin(q) {
  const lat = num(q.lat), lng = num(q.lng);
  if (lat !== null && lng !== null && Math.abs(lat) <= 90 && Math.abs(lng) <= 180) {
    return { lat, lng, label: 'you' };
  }
  const a = q.area && areaById(q.area);
  if (a) return { lat: a.lat, lng: a.lng, label: a.name };
  return { ...CITY_CENTRE, label: 'Salem centre' };
}

function listingView(l, origin) {
  const s = shopById(l.shopId);
  const p = productById(l.productId);
  const area = areaById(s.area);
  return {
    id: l.id,
    productId: p.id,
    productName: p.name,
    category: p.category,
    shop: {
      id: s.id, name: s.name, area: s.area, areaName: area ? area.name : s.area,
      phone: s.phone, whatsapp: s.whatsapp, lat: s.lat, lng: s.lng, mapUrl: mapUrl(s),
    },
    price: l.price,
    mrp: p.mrp,
    discountPct: discountPct(l.price, p.mrp),
    stock: l.stock,
    inStock: l.stock > 0,
    emi: l.emi,
    freebies: l.freebies || [],
    updatedAt: l.updatedAt,
    distanceKm: haversineKm(origin, s),
  };
}

const approvedShopIds = () => new Set(db().shops.filter((s) => s.status === 'approved').map((s) => s.id));

function sorter(sort) {
  const stockFirst = (a, b) => Number(b.inStock) - Number(a.inStock);
  const by = {
    price: (a, b) => a.price - b.price,
    nearest: (a, b) => a.distanceKm - b.distanceKm || a.price - b.price,
    discount: (a, b) => b.discountPct - a.discountPct || a.price - b.price,
  }[sort] || ((a, b) => a.price - b.price);
  return (a, b) => stockFirst(a, b) || by(a, b);
}

/* ------------------------------------------------------------------ auth */
const b64 = (b) => Buffer.from(b).toString('base64url');
function signToken(payload, ttlSec = 60 * 60 * 12) {
  const body = b64(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + ttlSec }));
  const sig = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}
function verifyToken(token) {
  if (!token || !token.includes('.')) return null;
  const [body, sig] = token.split('.');
  const expect = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  const a = Buffer.from(sig), b = Buffer.from(expect);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    return payload.exp > Date.now() / 1000 ? payload : null;
  } catch { return null; }
}
function requireRole(ctx, role) {
  if (!ctx.user || ctx.user.role !== role) throw new HttpError(401, 'Please log in');
  return ctx.user;
}

const otps = new Map(); // phone -> { code, exp, tries }
const otpLastSent = new Map(); // phone -> timestamp (kept separately so the throttle survives a verify)

/* ----------------------------------------------------------------- routes */
const routes = [];
const route = (method, pattern, handler) => {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '/?$');
  routes.push({ method, re, keys, handler });
};

route('GET', '/api/health', () => ({ ok: true, time: new Date().toISOString() }));
route('GET', '/api/areas', () => ({ areas: db().areas }));
route('GET', '/api/catalog', () => ({
  products: db().products.map(({ id, name, brand, category, mrp }) => ({ id, name, brand, category, mrp })),
}));

/* ---- search & compare ---- */
route('GET', '/api/search', ({ query }) => {
  const origin = parseOrigin(query);
  const tokens = String(query.q || '').toLowerCase().split(/\s+/).filter(Boolean);
  const okShops = approvedShopIds();
  const cmp = sorter(query.sort);

  const groups = [];
  for (const p of db().products) {
    const hay = [p.name, p.brand, p.category, ...(p.aliases || [])].join(' ').toLowerCase();
    if (!tokens.every((t) => hay.includes(t))) continue;

    let ls = db().listings.filter((l) => l.productId === p.id && okShops.has(l.shopId)).map((l) => listingView(l, origin));
    if (query.area) ls = ls.filter((l) => l.shop.area === query.area);
    if (!ls.length) continue;
    ls.sort(cmp);

    const prices = ls.filter((l) => l.inStock).map((l) => l.price);
    groups.push({
      product: { id: p.id, name: p.name, brand: p.brand, category: p.category, mrp: p.mrp },
      stats: prices.length
        ? { lowest: Math.min(...prices), highest: Math.max(...prices), average: Math.round(prices.reduce((a, b) => a + b, 0) / prices.length), shops: ls.length }
        : { lowest: null, highest: null, average: null, shops: ls.length },
      listings: ls,
    });
  }
  groups.sort((a, b) => (tokens.length ? 0 : a.product.name.localeCompare(b.product.name)));
  return { query: query.q || '', sort: query.sort || 'price', distanceFrom: origin.label, results: groups.slice(0, 20) };
});

/* ---- budget ---- */
route('GET', '/api/budget', ({ query }) => {
  const amount = num(query.amount);
  if (!amount || amount < 500 || amount > 1e7) throw bad('amount must be between 500 and 10000000');
  const priority = ['value', 'price', 'discount', 'distance'].includes(query.priority) ? query.priority : 'value';
  const origin = parseOrigin(query);
  const okShops = approvedShopIds();

  const picks = [];
  for (const p of db().products) {
    const options = db().listings
      .filter((l) => l.productId === p.id && l.stock > 0 && l.price <= amount && okShops.has(l.shopId))
      .map((l) => listingView(l, origin));
    if (!options.length) continue;

    const score = (v) => {
      if (priority === 'price') return -v.price;
      if (priority === 'discount') return v.discountPct * 1000 - v.price / 1000;
      if (priority === 'distance') return -v.distanceKm * 1000 - v.price / 1000;
      return v.discountPct * 1.5 + (v.price / amount) * 40 - v.distanceKm * 0.5; // value
    };
    options.sort((a, b) => score(b) - score(a));
    const best = options[0];
    const bits = [`₹${best.price.toLocaleString('en-IN')} is ₹${(amount - best.price).toLocaleString('en-IN')} under budget`];
    if (best.discountPct) bits.push(`${best.discountPct}% below MRP`);
    bits.push(`${best.distanceKm} km away`);
    picks.push({ best, otherShops: options.length - 1, reason: bits.join(' • '), _score: score(best) });
  }
  picks.sort((a, b) => b._score - a._score);
  return { amount, priority, distanceFrom: origin.label, picks: picks.slice(0, 12).map(({ _score, ...r }) => r) };
});

/* ---- repair shops ---- */
route('GET', '/api/repairs', ({ query }) => {
  const origin = parseOrigin(query);
  const device = query.device || '';
  let list = db().repairShops.filter((r) => (!device || r.devices.includes(device)) && (!query.area || r.area === query.area));
  list = list.map((r) => ({
    id: r.id, name: r.name, area: r.area, areaName: (areaById(r.area) || {}).name || r.area,
    phone: r.phone, whatsapp: r.whatsapp, devices: r.devices,
    startingPrice: device ? r.startingPrice[device] : null,
    prices: r.startingPrice, turnaround: r.turnaround, warranty: r.warranty,
    distanceKm: haversineKm(origin, r), mapUrl: mapUrl(r),
  }));
  list.sort((a, b) => a.distanceKm - b.distanceKm);
  return { device, distanceFrom: origin.label, shops: list, note: 'Service prices are estimates confirmed by the shop.' };
});

/* ---- EMI ---- */
route('GET', '/api/emi', ({ query }) => {
  const price = num(query.price), down = num(query.down, 0), rate = num(query.rate, 0), months = num(query.months);
  if (!price || price <= 0) throw bad('price is required');
  if (down < 0 || down > price) throw bad('down payment must be between 0 and price');
  if (rate < 0 || rate > 60) throw bad('rate must be between 0 and 60');
  if (!months || months < 1 || months > 60) throw bad('months must be between 1 and 60');
  return { price, down, rate, months, ...emiCalc(price, down, rate, months), note: 'Shop EMI offers may differ. This is an estimate.' };
});

/* ---- OTP login (demo) ---- */
route('POST', '/api/auth/otp/request', ({ body }) => {
  const phone = normalisePhone(body.phone);
  if (!phone) throw bad('Enter a valid 10-digit mobile number');
  if (Date.now() - (otpLastSent.get(phone) || 0) < 30000) throw new HttpError(429, 'Please wait 30 seconds before requesting another OTP');
  const code = String(crypto.randomInt(100000, 1000000));
  otpLastSent.set(phone, Date.now());
  otps.set(phone, { code, exp: Date.now() + 5 * 60 * 1000, tries: 0 });
  // TODO (production): send `code` via an SMS provider (MSG91, Twilio, Fast2SMS...). Never return it then.
  console.log(`[OTP] ${phone}: ${code}`);
  return { sent: true, ...(IS_PROD ? {} : { devOtp: code }) };
});

route('POST', '/api/auth/otp/verify', ({ body }) => {
  const phone = normalisePhone(body.phone);
  const entry = phone && otps.get(phone);
  if (!entry || entry.exp < Date.now()) throw bad('OTP expired. Request a new one.');
  if (++entry.tries > 5) { otps.delete(phone); throw new HttpError(429, 'Too many attempts. Request a new OTP.'); }
  const given = Buffer.from(String(body.otp || '').padEnd(6, ' ').slice(0, 6));
  const real = Buffer.from(entry.code);
  if (!crypto.timingSafeEqual(given, real)) throw bad('Incorrect OTP');
  otps.delete(phone);

  const shop = db().shops.find((s) => s.phone === phone);
  if (!shop) throw new HttpError(404, 'No shop is registered with this number. Please sign up first.');
  if (shop.status !== 'approved') throw new HttpError(403, `Your shop is ${shop.status}. You can log in once it is approved.`);
  return { token: signToken({ role: 'shop', sub: shop.id }), shop: { id: shop.id, name: shop.name } };
});

/* ---- shop signup (public) ---- */
route('POST', '/api/shops/signup', ({ body }) => {
  const name = String(body.name || '').trim();
  const phone = normalisePhone(body.phone);
  const area = areaById(body.area);
  if (name.length < 2 || name.length > 60) throw bad('Shop name must be 2-60 characters');
  if (!phone) throw bad('Enter a valid 10-digit mobile number');
  if (!area) throw bad('Choose an area');
  if (db().shops.some((s) => s.phone === phone)) throw new HttpError(409, 'This number is already registered');
  const shop = {
    id: store.nextId('shop'), name, area: area.id, phone, whatsapp: '91' + phone,
    lat: area.lat, lng: area.lng, status: 'pending', createdAt: new Date().toISOString(),
  };
  db().shops.push(shop);
  store.save();
  return { id: shop.id, status: shop.status, message: 'Submitted. You can log in after an admin approves your shop.' };
});

/* ---- shop dashboard (auth: shop) ---- */
const cleanListingInput = (b) => {
  const out = {};
  if (b.price !== undefined) {
    const v = num(b.price);
    if (v === null || !Number.isInteger(v) || v < 1 || v > 1e7) throw bad('price must be a whole number between 1 and 10000000');
    out.price = v;
  }
  if (b.stock !== undefined) {
    const v = num(b.stock);
    if (v === null || !Number.isInteger(v) || v < 0 || v > 9999) throw bad('stock must be a whole number between 0 and 9999');
    out.stock = v;
  }
  if (b.emi !== undefined) out.emi = String(b.emi).trim().slice(0, 80);
  if (b.freebies !== undefined) {
    const arr = Array.isArray(b.freebies) ? b.freebies : String(b.freebies).split(',');
    out.freebies = arr.map((x) => String(x).trim().slice(0, 40)).filter(Boolean).slice(0, 5);
  }
  return out;
};

route('GET', '/api/shop/me', (ctx) => {
  const u = requireRole(ctx, 'shop');
  const shop = shopById(u.sub);
  if (!shop) throw new HttpError(401, 'Shop not found');
  const origin = { lat: shop.lat, lng: shop.lng };
  return {
    shop: { id: shop.id, name: shop.name, area: shop.area, phone: shop.phone, status: shop.status },
    listings: db().listings.filter((l) => l.shopId === shop.id).map((l) => listingView(l, origin)),
  };
});

route('POST', '/api/shop/listings', (ctx) => {
  const u = requireRole(ctx, 'shop');
  const p = productById(ctx.body.productId);
  if (!p) throw bad('Unknown product');
  if (db().listings.some((l) => l.shopId === u.sub && l.productId === p.id)) throw new HttpError(409, 'You already list this product');
  if (ctx.body.price === undefined) throw bad('price is required');
  const data = cleanListingInput({ stock: 0, emi: '', freebies: [], ...ctx.body });
  const l = { id: store.nextId('listing'), shopId: u.sub, productId: p.id, price: 0, stock: 0, emi: '', freebies: [], ...data, updatedAt: new Date().toISOString() };
  db().listings.push(l);
  store.save();
  return { listing: listingView(l, shopById(u.sub)) };
});

route('PUT', '/api/shop/listings/:id', (ctx) => {
  const u = requireRole(ctx, 'shop');
  const l = db().listings.find((x) => x.id === ctx.params.id);
  if (!l || l.shopId !== u.sub) throw new HttpError(404, 'Listing not found');
  Object.assign(l, cleanListingInput(ctx.body), { updatedAt: new Date().toISOString() });
  store.save();
  return { listing: listingView(l, shopById(u.sub)) };
});

route('DELETE', '/api/shop/listings/:id', (ctx) => {
  const u = requireRole(ctx, 'shop');
  const i = db().listings.findIndex((x) => x.id === ctx.params.id && x.shopId === u.sub);
  if (i < 0) throw new HttpError(404, 'Listing not found');
  db().listings.splice(i, 1);
  store.save();
  return { deleted: true };
});

/* ---- admin ---- */
route('POST', '/api/admin/login', ({ body }) => {
  const given = Buffer.from(crypto.createHash('sha256').update(String(body.password || '')).digest());
  const real = Buffer.from(crypto.createHash('sha256').update(ADMIN_PASSWORD).digest());
  if (!crypto.timingSafeEqual(given, real)) throw new HttpError(401, 'Wrong password');
  return { token: signToken({ role: 'admin' }, 60 * 60 * 4) };
});

route('GET', '/api/admin/shops', (ctx) => {
  requireRole(ctx, 'admin');
  return { shops: db().shops.map((s) => ({ ...s, areaName: (areaById(s.area) || {}).name })) };
});

route('POST', '/api/admin/shops/:id/:action', (ctx) => {
  requireRole(ctx, 'admin');
  const s = shopById(ctx.params.id);
  if (!s) throw new HttpError(404, 'Shop not found');
  if (!['approve', 'reject'].includes(ctx.params.action)) throw bad('Unknown action');
  s.status = ctx.params.action === 'approve' ? 'approved' : 'rejected';
  store.save();
  return { shop: s };
});

/* ----------------------------------------------------------- http plumbing */
function send(res, status, data, extra = {}) {
  const body = typeof data === 'string' ? data : JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': typeof data === 'string' ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': CORS_ORIGIN,
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'X-Content-Type-Options': 'nosniff',
    ...extra,
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 100 * 1024) { reject(new HttpError(413, 'Body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); } catch { reject(bad('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
};

function serveStatic(req, res, pathname) {
  if (!fs.existsSync(FRONTEND_DIR)) return send(res, 404, 'Not found');
  let rel = decodeURIComponent(pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(FRONTEND_DIR, rel));
  if (!file.startsWith(FRONTEND_DIR + path.sep)) return send(res, 403, 'Forbidden'); // path traversal guard
  fs.readFile(file, (err, buf) => {
    if (err) return send(res, 404, 'Not found');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' });
    res.end(buf);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (req.method === 'OPTIONS') return send(res, 204, '');

    if (!url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET') return send(res, 405, 'Method not allowed');
      return serveStatic(req, res, url.pathname);
    }

    let matched = null, params = {}, pathMatched = false;
    for (const r of routes) {
      const m = r.re.exec(url.pathname);
      if (!m) continue;
      pathMatched = true;
      if (r.method !== req.method) continue;
      matched = r;
      r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
      break;
    }
    if (!matched) return send(res, pathMatched ? 405 : 404, { error: pathMatched ? 'Method not allowed' : 'Not found' });

    const auth = req.headers.authorization || '';
    const ctx = {
      req, params,
      query: Object.fromEntries(url.searchParams),
      body: ['POST', 'PUT', 'PATCH'].includes(req.method) ? await readBody(req) : {},
      user: verifyToken(auth.startsWith('Bearer ') ? auth.slice(7) : ''),
    };
    const out = await matched.handler(ctx);
    send(res, 200, out);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message });
    console.error(e);
    send(res, 500, { error: 'Something went wrong' });
  }
});

if (require.main === module) {
  server.listen(PORT, () => console.log(`Gadget Street running on http://localhost:${PORT}`));
}
module.exports = { server };
